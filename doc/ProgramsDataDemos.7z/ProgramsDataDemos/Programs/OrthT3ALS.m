function [relerr,U,V,W,G]=OrthT3ALS(X,r1,r2,r3);

% Orthogonal Tucker3 ALS (with HOSVD initialization)
% Nikos Sidiropoulos
% UMN, Feb. 2016

% Magic numbers, control ALS loop below:

SMALLNUMBER = 10^8*eps;
ANOTHERSMALLNUMBER = 10^8*eps;
MAXNUMITER = 1000;

[I, J, K]=size(X);

% construct three different unfolded data matrices:

% Used in the A-update step:
X1=zeros(K*J,I);
for i=1:I,
    X1(:,i)=vec(squeeze(X(i,:,:)));
end

% Used in the B-update step:
X2=zeros(I*K,J);
for j=1:J,
    X2(:,j)=vec(squeeze(X(:,j,:)));
end

% Used in the C-update step:
X3=zeros(I*J,K);
for k=1:K,
    X3(:,k)=vec(squeeze(X(:,:,k)));
end

[U,dummy1,dummy2] = svds(X1.',r1);
[V,dummy1,dummy2] = svds(X2.',r2);
[W,dummy1,dummy2] = svds(X3.',r3);

Y=zeros(r1,r2,K);
for k=1:K,
    Y(:,:,k)=U.'*squeeze(X(:,:,k))*V;
end
G=zeros(r1,r2,r3);
for r=1:r2,
    G(:,r,:)=squeeze(Y(:,r,:))*W;
end

% Reshape G into G3:
G3=zeros(r1*r2,r3);
for r=1:r3,
    G3(:,r)=vec(squeeze(G(:,:,r)));
end

% compute current fit:
fit = norm(X3-kron(V,U)*G3*W.','fro')^2;

fprintf('fit = %12.10f\n',fit);
fitold = 2*fit;
fitinit = fit;
it     = 0;
allfits = [];

while abs((fit-fitold)/fitold) > SMALLNUMBER & it < MAXNUMITER & fit > ANOTHERSMALLNUMBER
 it=it+1;
 fitold=fit;

 [U,dummy1,dummy2] = svds(X1.'*kron(W,V),r1);
 [V,dummy1,dummy2] = svds(X2.'*kron(W,U),r2);
 [W,dummy1,dummy2] = svds(X3.'*kron(V,U),r3);


 for k=1:K,
     Y(:,:,k)=U.'*squeeze(X(:,:,k))*V;
 end
 G=zeros(r1,r2,r3);
 for r=1:r2,
     G(:,r,:)=squeeze(Y(:,r,:))*W;
 end

 % Reshape G into G3:
 G3=zeros(r1*r2,r3);
 for r=1:r3,
     G3(:,r)=vec(squeeze(G(:,:,r)));
 end

% compute current fit:
fit = norm(X3-kron(V,U)*G3*W.','fro')^2;
 
 allfits = [allfits; fit];
 plot(allfits);
 drawnow;

fprintf('fit = %12.10f\n',fit);

end % while loop

relerr = fit/norm(X3,'fro')^2;

% end of algorithm

function vecA = vec(A);
[I F] = size(A);
vecA=zeros(I*F,1);
for f=1:F,
    vecA(I*(f-1)+1:I*f)=A(:,f);
end

