% Simple blind speech separation demo using PARAFAC
% on a set of locally-averaged correlation matrices
% exploiting uncorrelatedness of the two speech sources
% and time variation in speech power 

% Only instantaneous speech mixtures considered for 
% simplicity of exposition; for the more general case 
% see 

% D. Nion, K. Mokios, N.D. Sidiropoulos, A. Potamianos, 
% ``Batch and Adaptive PARAFAC-Based Blind Separation of 
% Convolutive Speech Mixtures��, IEEE Trans. on Audio, 
% Speech and Language Processing, 18(6):1193-1207, Aug. 2010. 

% Nikos Sidiropoulos, UMN, Aug. 2015

clear all;
close all;

[s1,FS]=audioread('Speech1.wav');
[s2,FS]=audioread('Speech2.wav');
s2=s2(1:length(s1)); % make equal length
p=audioplayer(s1,FS); play(p);
pause(1);
p=audioplayer(s2,FS); play(p);

A=randn(2,2);
ms=A*[s1'; s2']; % two mixed signals
p=audioplayer(ms(1,:),FS); play(p);
%pause(1);
%p=audioplayer(ms(2,:),FS); play(p);

X=zeros(2,2,50);
seglen=length(s1)/50; % segment length
for k=1:50,
    seg=ms(:,(k-1)*seglen+1:k*seglen);
    X(:,:,k)=seg*seg'; % estimated correlation matrix for the k-th segment
end

[estA,estB,estC]=PVALS(X,2);

A
estA
A(:,1)/A(1,1)
A(:,2)/A(1,2)
estA(:,1)/estA(1,1)
estA(:,2)/estA(1,2)
% what do you observe?

separated = inv(estA)*ms;
p=audioplayer(separated(1,:),FS); play(p);
pause(1);
p=audioplayer(separated(2,:),FS); play(p);



    

