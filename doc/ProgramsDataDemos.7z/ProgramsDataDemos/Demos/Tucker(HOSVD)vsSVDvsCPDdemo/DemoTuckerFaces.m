function DemoTuckerFaces

% Demonstration of Tucker (specifically: HOSVD)-based tensor compression,
% vs. matrix SVD

% Nikos Sidiropoulos, University of Minnesota, Feb. 17, 2016

clear all;
close all;

% You need to download the nway toolbox by Rasmus Bro, and addpath to it.
% For the toolbox, see http://www.models.life.ku.dk/nwaytoolbox/download

addpath Y:\windows\nway
 
load FERETC80A45
%who
X=fea2D;
[I,J,K]=size(X);

figure(1); image(X(:,:,45));
figure(2); image(X(:,:,167));

disp('pressreturn:'); pause;

%help tucker
[Factors,G,ExplX,Xm]=tucker(X,[5 5 15]);

%Factors{1}
%Factors{2}
%Factors{3}

%X is 32x32x320; U=Factors{1} is 32x5, same for V=Factors{2}, whereas
%Factors{3} is 320x15. Core G is 5x5x15

%Xm is the approximation of tensor X using the reduced core;

signal2=0;
error2=0;
for k=1:K
 signal2=signal2+norm(X(:,:,k),'fro')^2;
 error2=error2+norm(X(:,:,k)-Xm(:,:,k),'fro')^2;
end

rel_tucker_error = error2/signal2

disp('press return:'); pause;

% total # floats used by tucker is 5*32+5*32+15*320+5*5*15=5495
% let's try taking the SVD of the unfolded tensor instead, namely:

Y=zeros(I*J,K);
for k=1:K, 
    Y(:,k)=vec(X(:,:,k)); 
end

% If we truncate the SVD of Y to r components, then we use (I*J+K)*r floats
% i.e., (1024+320)*r to store the two matrix factors. If we pick r=4, we
% get 5376 floats, slightly below 5495 used by Tucker; for r=5, we get 6720 floats. 

[Uy,Sy,Vy]=svds(Y,5);

SVDerror2=norm(Y-Uy*Sy*Vy','fro')^2;

rel_svd_error = SVDerror2/signal2

disp('press return:'); pause;

% What about using PARAFAC aka CPD for compression?  
% PARAFAC: (I+J+K)*F=384*F, so we can use F=14 --> 5376 floats

Factors = parafac(X,14);
A=Factors{1};
B=Factors{2};
C=Factors{3};

Xp=zeros(size(X));
for k=1:K, 
    Xp(:,:,k)=A*diag(C(k,:))*B.';
end

CPDerror2=0;
for k=1:K
 CPDerror2=CPDerror2+norm(X(:,:,k)-Xp(:,:,k),'fro')^2;
end

rel_cpd_error = CPDerror2/signal2

disp('press return:'); pause;

% Let's do some more compression: 

[Factors,G,ExplX,Xm]=tucker(X,[3 3 5]); % # floats: 1822

signal2=0;
error2=0;
for k=1:K
 signal2=signal2+norm(X(:,:,k),'fro')^2;
 error2=error2+norm(X(:,:,k)-Xm(:,:,k),'fro')^2;
end

rel_tucker_error = error2/signal2

disp('press return:'); pause;

[Uy,Sy,Vy]=svds(Y,2);

rank2SVDerror2=norm(Y-Uy*Sy*Vy','fro')^2;
rank1SVDerror2=norm(Y-Uy(:,1)*Sy(1,1)*Vy(:,1)','fro')^2;

rel_rank2_svd_error = rank2SVDerror2/signal2
rel_rank1_svd_error = rank1SVDerror2/signal2

disp('press return:'); pause;

% PARAFAC: (I+J+K)*F=383*F, so we can use F=5 --> 1920 floats

Factors = parafac(X,5);
A=Factors{1};
B=Factors{2};
C=Factors{3};

Xp=zeros(size(X));
for k=1:K, 
    Xp(:,:,k)=A*diag(C(k,:))*B.';
end

CPDerror2=0;
for k=1:K
 CPDerror2=CPDerror2+norm(X(:,:,k)-Xp(:,:,k),'fro')^2;
end

rel_cpd_error = CPDerror2/signal2

function vecA = vec(A);
[I F] = size(A);
vecA=zeros(I*F,1);
for f=1:F,
    vecA(I*(f-1)+1:I*f)=A(:,f);
end

