%test GD vs SGD for CPD

clear all;
close all;
clf;
I=10; J=10; K=10; F=20;
X=randn(I,J,K);
A0=randn(I,F); B0=randn(K,F); C0=randn(K,F);
[A,B,C]=GD4CPD(X,15,A0,B0,C0);
hold on;
[A,B,C]=SGD4CPD(X,F,A0,B0,C0);
[A,B,C]=PVALS(X,F,A0,B0,C0);
legend('GD','SGD','ALS');

clf;
F=5;
A=randn(I,F);
A(:,2)=0.05*A(:,2)+0.95*A(:,1); 
B=randn(J,F);
C=randn(K,F);
A0=randn(I,F); B0=randn(K,F); C0=randn(K,F);
[A,B,C]=GD4CPD(X,F,A0,B0,C0);
hold on;
[A,B,C]=SGD4CPD(X,F,A0,B0,C0);
[A,B,C]=PVALS(X,F,A0,B0,C0);
legend('GD','SGD','ALS');

clf;
F=5;
A=randn(I,F);
A(:,2)=0.05*A(:,2)+0.95*A(:,1); 
B=A;
C=A;
A0=randn(I,F); B0=randn(K,F); C0=randn(K,F);
[A,B,C]=GD4CPD(X,F,A0,B0,C0);
hold on;
[A,B,C]=SGD4CPD(X,F,A0,B0,C0);
[A,B,C]=PVALS(X,F,A0,B0,C0);
legend('GD','SGD','ALS');
