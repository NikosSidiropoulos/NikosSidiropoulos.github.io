function [A,B,C]=PVALS(X,F,A,B,C);

% Plain-Vanilla Alternating Least Squares
% X = IxJxK rank-F 3-way array
% Nikos Sidiropoulos
% UMN, Jan. 2016

% Magic numbers, control ALS loop below:

SMALLNUMBER = 10^8*eps;
ANOTHERSMALLNUMBER = 10^8*eps;
MAXNUMITER = 1000;

[I, J, K]=size(X);

% initial estimates:

if (nargin < 5)
 disp('Using random initial estimates ...');
 A = randn(I,F);
 B = randn(J,F);
 C = randn(K,F);
end

% construct three different unfolded data matrices:

% Used in the A-update step:
X1=zeros(K*J,I);
for i=1:I,
    X1(:,i)=vec(squeeze(X(i,:,:)));
end

% Used in the B-update step:
X2=zeros(I*K,J);
for j=1:J,
    X2(:,j)=vec(squeeze(X(:,j,:)));
end

% Used in the C-update step:
X3=zeros(I*J,K);
for k=1:K,
    X3(:,k)=vec(squeeze(X(:,:,k)));
end

% compute current fit:
fit = 0;
for k=1:K,
  model(:,:,k) = A*diag(C(k,:))*B.';
  fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
end

%fprintf('fit = %12.10f\n',fit);
fitold = 2*fit;
fitinit = fit;
it     = 0;
allfits = [];

while abs((fit-fitold)/fitold) > SMALLNUMBER & it < MAXNUMITER & fit > ANOTHERSMALLNUMBER
 it=it+1;
 fitold=fit;

 A = (krp(C,B)\X1).'; %(pinv(krp(C,B))*X1).'; 
 B = (krp(C,A)\X2).'; %(pinv(krp(C,A))*X2).'; 
 C = (krp(B,A)\X3).'; %(pinv(krp(B,A))*X3).';
 
 % compute new fit:
 fit = 0;
 for k=1:K,
   model(:,:,k) = A*diag(C(k,:))*B.';
   fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
 end
 allfits = [allfits; fit];
 plot(allfits);
 drawnow;

fprintf('fit = %12.10f\n',fit);

end % while loop

% end of algorithm

function vecA = vec(A);
[I F] = size(A);
vecA=zeros(I*F,1);
for f=1:F,
    vecA(I*(f-1)+1:I*f)=A(:,f);
end

function AkrpB = krp(A,B);

[I F] = size(A);
[J F1] = size(B);

if (F1 ~= F)
 disp('krp.m: column dimensions do not match!!! - exiting matlab');
 exit;
end

AkrpB = zeros(I*J,F);
for f=1:F,
 AkrpB(:,f) = kron(A(:,f),B(:,f));
end

