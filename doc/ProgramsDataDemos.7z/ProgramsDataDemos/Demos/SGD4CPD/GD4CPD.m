function [A,B,C]=GD4CPD(X,F,A,B,C);

% Plain-Vanilla GD for CPD
% X = IxJxK rank-F 3-way array
% Nikos Sidiropoulos
% UMN, Apr. 2016

% Magic numbers, control loop below:

SMALLNUMBER = 10^8*eps;
ANOTHERSMALLNUMBER = 10^8*eps;
MAXNUMITER = 1000;
stepsize = 1E-3; 

[I, J, K]=size(X);

% initial estimates:

if (nargin < 5)
 disp('Using random initial estimates ...');
 A = randn(I,F);
 B = randn(J,F);
 C = randn(K,F);
end

% construct three different unfolded data matrices:

% Used in the A-update step:
X1=zeros(K*J,I);
for i=1:I,
    X1(:,i)=vec(squeeze(X(i,:,:)));
end

% Used in the B-update step:
X2=zeros(I*K,J);
for j=1:J,
    X2(:,j)=vec(squeeze(X(:,j,:)));
end

% Used in the C-update step:
X3=zeros(I*J,K);
for k=1:K,
    X3(:,k)=vec(squeeze(X(:,:,k)));
end

% compute current fit:
fit = 0;
for k=1:K,
  model(:,:,k) = A*diag(C(k,:))*B.';
  fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
end

%fprintf('fit = %12.10f\n',fit);
fitold = 2*fit;
fitinit = fit;
it     = 0;
allfits = [];

while abs((fit-fitold)/fitold) > SMALLNUMBER & it < MAXNUMITER & fit > ANOTHERSMALLNUMBER
 it=it+1;
 fitold=fit;

 A = A+stepsize*2*(X1.'*krp(C,B)-A*((C.'*C).*(B.'*B)));
 B = B+stepsize*2*(X2.'*krp(C,A)-B*((C.'*C).*(A.'*A)));
 C = C+stepsize*2*(X3.'*krp(B,A)-C*((B.'*B).*(A.'*A)));
  
 % compute new fit:
 fit = 0;
 for k=1:K,
   model(:,:,k) = A*diag(C(k,:))*B.';
   fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
 end
 allfits = [allfits; fit];
 semilogy(allfits);
 grid on;
 drawnow;

fprintf('fit = %12.10f\n',fit);

end % while loop

% end of algorithm

function vecA = vec(A);
[I F] = size(A);
vecA=zeros(I*F,1);
for f=1:F,
    vecA(I*(f-1)+1:I*f)=A(:,f);
end

function AkrpB = krp(A,B);

[I F] = size(A);
[J F1] = size(B);

if (F1 ~= F)
 disp('krp.m: column dimensions do not match!!! - exiting matlab');
 exit;
end

AkrpB = zeros(I*J,F);
for f=1:F,
 AkrpB(:,f) = kron(A(:,f),B(:,f));
end

