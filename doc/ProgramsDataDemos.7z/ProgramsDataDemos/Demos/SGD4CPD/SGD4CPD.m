function [A,B,C]=GD4CPD(X,F,A,B,C);

% Plain-Vanilla SGD for CPD
% X = IxJxK rank-F 3-way array
% Nikos Sidiropoulos
% UMN, Apr. 2016

% Magic numbers, control loop below:

ANOTHERSMALLNUMBER = 10^8*eps;
[I, J, K]=size(X);
MAXNUMITER = 1000*I*J*K;
stepsize = 1E-3; 

% initial estimates:

if (nargin < 5)
 disp('Using random initial estimates ...');
 A = randn(I,F);
 B = randn(J,F);
 C = randn(K,F);
end

% compute current fit:
fit = 0;
for k=1:K,
  model(:,:,k) = A*diag(C(k,:))*B.';
  fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
end
fprintf('fit = %12.10f\n',fit);

it     = 0;
allfits = [];

while it < MAXNUMITER & fit > ANOTHERSMALLNUMBER
 it=it+1;
 
 i=randi(I,1); j=randi(J,1); k=randi(K,1);
 
 A(i,:)=A(i,:)+stepsize*2*(X(i,j,k)-sum(A(i,:).*B(j,:).*C(k,:)))*(B(j,:).*C(k,:));
 B(j,:)=B(j,:)+stepsize*2*(X(i,j,k)-sum(A(i,:).*B(j,:).*C(k,:)))*(A(i,:).*C(k,:));
 C(k,:)=C(k,:)+stepsize*2*(X(i,j,k)-sum(A(i,:).*B(j,:).*C(k,:)))*(A(i,:).*B(j,:));
  
 if mod(it,I*J*K)==0
    % compute new fit:
    fit = 0;
    for k=1:K,
        model(:,:,k) = A*diag(C(k,:))*B.';
        fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
    end
    allfits = [allfits; fit];
    semilogy(allfits);
    grid on;
    drawnow;
    fprintf('fit = %12.10f\n',fit);
 end

end % while loop

% end of algorithm

